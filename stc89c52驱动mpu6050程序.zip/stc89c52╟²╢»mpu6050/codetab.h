#ifndef __CODETAB_H__
#define __CODETAB_H__

extern const unsigned char code baihuzi[];
extern const unsigned char code F8X16[];
extern const unsigned char code muye[];
extern const unsigned char code tubiao[];
#endif

