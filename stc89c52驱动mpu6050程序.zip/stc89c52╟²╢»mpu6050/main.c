#include "reg52.h"
#include "MPU_6050.h"
#include "oled.h"
#include "codetab.h"


void main(void)
{
	unsigned char bmp_flag = 0;
	char bmp_num = 0;
	InitMPU6050();	//mpu6050��ʼ��
	OLED_Init(); //OLED��ʼ��
	OLED_BMP(0,0,baihuzi);
	for(;;)	//��ѭ��
	{ 
		Read_Mpu6050();	//��ȡ���ٶ�
		if(MPU6050_Data.Gyro_Y > 7000)
		{
			bmp_num += 1;
			bmp_flag = 1;
			if(bmp_num >= 3)
			{
				bmp_num = 0;
			}
		}
		else if(MPU6050_Data.Gyro_Y < -7000)
		{
			bmp_num -= 1;
			bmp_flag = 1;
			if(bmp_num < 0)
			{
				bmp_num = 2;
			}
		}
		if(bmp_flag == 1)	//ѡ����ʾͼƬ
		{
			switch(bmp_num)
			{
				case 0:
					OLED_BMP(0,0,baihuzi);
					bmp_flag = 0;
					break;
				case 1:
					OLED_BMP(0,0,muye);
					bmp_flag = 0;
					break;
				case 2:
					OLED_BMP(0,0,tubiao);
					bmp_flag = 0;
					break;
				default:
					break;
			}
		}
		
	}
}





